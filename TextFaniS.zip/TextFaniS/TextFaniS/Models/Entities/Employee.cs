﻿using System.ComponentModel.DataAnnotations;

namespace TextFaniS.Models.Entities
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public required string FirstName { get; set; }

        [Required]
        public required string LastName { get; set; }

        [Range(0, 120)] // اعتبارسنجی برای سن  
        public int Age { get; set; }

        public required string NationalCode { get; set; }
    }
}