﻿using Microsoft.AspNetCore.Mvc;
using TextFaniS.Data;
using TextFaniS.Models;
using TextFaniS.Models.Entities;

namespace TextFaniS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly ApplicationDbContext dbContext;

        public EmployeesController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        // متد GET برای دریافت اطلاعات یک کارمند بر اساس نام، نام خانوادگی و کد ملی
        [HttpGet("{firstName}/{lastName}/{nationalCode}")]
        public IActionResult GetEmployee(string firstName, string lastName, string nationalCode)
        {
            var employee = dbContext.Employees
                .FirstOrDefault(e => e.FirstName == firstName
                                  && e.LastName == lastName
                                  && e.NationalCode == nationalCode); // استفاده از کد ملی به صورت string

            if (employee == null)
            {
                return NotFound(new { Status = "NotFound", Result = "کارمند یافت نشد" });
            }

            var result = new
            {
                Name = employee.FirstName,
                Family = employee.LastName,
                Code = employee.NationalCode,
                Status = "OK",
                EmploymentStatus = "وضعیت استخدامی شما با موفقیت بررسی شد"
            };

            return Ok(result);
        }

        // متد POST برای ایجاد یک کارمند جدید
        [HttpPost]
        public IActionResult CreateEmployee([FromBody] EmployeeCreateDto employeeDto)
        {
            if (employeeDto == null)
            {
                return BadRequest("Invalid data.");
            }

            var employee = new Employee
            {
                FirstName = employeeDto.FirstName,
                LastName = employeeDto.LastName,
                Age = employeeDto.Age,
                NationalCode = employeeDto.NationalCode // کد ملی به صورت string
            };

            dbContext.Employees.Add(employee);
            dbContext.SaveChanges();

            var result = new
            {
                Status = "OK",
                FullDes = $"{employee.FirstName} {employee.LastName} با سن {employee.Age} و کد ملی {employee.NationalCode} در پایگاه داده ثبت شد."
            };

            return Ok(result);
        }
    }
}

