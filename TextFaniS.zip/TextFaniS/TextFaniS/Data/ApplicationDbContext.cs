﻿using Microsoft.EntityFrameworkCore;
using TextFaniS.Models.Entities;

namespace TextFaniS.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) {
        }

        public DbSet<Employee> Employees {  get; set; }

    }
}
